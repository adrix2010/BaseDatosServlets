drop database if exists gastos;
create database gastos;
use gastos;

drop table if exists gastos;
create table gastos(
idGasto int not null primary key,
nombreG nvarchar(50) not null,
servicio nvarchar(50) not null,
prestador nvarchar(50) not null,
fechaG nvarchar(50) not null, 
cantidad float not null
);
 
 drop procedure if exists spInsertaGasto;
 delimiter $$
 create procedure spInsertaGasto(
 in nombre nvarchar(50),
in service nvarchar(50),
in presta nvarchar(50),
in fecha nvarchar(50), 
in cantidad float) 
begin

declare ec int;
declare idG int;
declare mensaje nvarchar(100);

set ec =(select count(*)from gastos where nombreG = nombre);
if (ec = 0) then
		set idG = (select ifnull(max(idGasto), 0) + 1 from gastos);
        insert into gastos(idGasto, nombreG, servicio, prestador, fechaG, cantidad)
				values(idG, nombre, service, presta , fecha, cantidad);
		set mensaje = 'Gasto insertado';
else 
         set idG = -1;
         set mensaje = 'Gasto ya ingresado';
end if;
      select * from gastos;
   end; $$
   
  
   select * from gastos;